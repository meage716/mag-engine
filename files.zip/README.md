# Mag Engine

C dilinde sıfırdan yazılmış 2D/3D oyun motoru. Win32 üzerinde çalışır, hiçbir
harici grafik kütüphanesi (OpenGL, DirectX, SDL) kullanmaz — tüm rendering
yazılım tabanlı.

## Özellikler

- Vektör tabanlı 3D raycasting renderer (Doom tarzı)
- 2D top-down mod (Yuppie Psycho tarzı)
- Floor/ceiling casting
- Sprite billboards
- Point light sistemi
- Fog
- Partiküller (kan, duman, kıvılcım)
- Spring fizik (silah bob için)
- Entity sistemi (NPC, item, monster)
- Diyalog sistemi
- Envanter
- Kamera shake
- Fade in/out geçiş
- Timer sistemi
- Bitmap font

## Derleme

Windows + MSVC gerekli. Visual Studio Developer Command Prompt aç ve:

```
build.bat
```

## Kontroller (demo oyun)

- `W/A/S/D` — hareket
- `Sol tık` — ateş et
- `Space` — zıpla
- `C` — eğil
- `ESC` — çıkış

## Yapı

- `engine.c` / `engine.h` — motor kodu
- `main.c` — demo oyun
- `stb_image.h` — PNG yükleyici (Sean Barrett)
- `build.bat` — derleme scripti

## Lisans

MIT
